# SnakeByte v9 — Liquid Glass Python Quest v8 — 3D Python Quest

SnakeByte is a responsive Python-learning app packaged as an Android APK with the same web UI usable as a PWA.

## v8 upgrades
- 3D-style Python motion graphics and animated execution theatre.
- Real Pyodide Python execution with a worker timeout.
- Python examples are normalized to double-quoted strings.
- Expanded curriculum: basics, logic, loops, collections, functions, errors, OOP, JSON, async, APIs, app architecture, automation, testing and project thinking.
- Topic search across the full curriculum.
- No seeded/fake enrollment names.
- Optional Google Apps Script enrollment collector for real users.
- Admin panel can load the real enrollment list when the owner API is configured.
- Minimal 2D Python app icon.
- Android min SDK 23 for older devices such as Samsung M31-class hardware.
- GitHub Actions builds a debug APK with one workflow run.

## Real user enrollment
The app stores the enrollment locally first. To see users from different devices:
1. Create a Google Sheet.
2. Open Extensions → Apps Script and paste `backend/google-apps-script/Code.gs`.
3. Replace `CHANGE_THIS_TO_A_LONG_RANDOM_KEY` with your own random key.
4. Deploy as a Web App and allow the app to reach the deployed endpoint.
5. Paste the `/exec` URL into `USER_API_URL` in `index.html`.
6. Put the same key into `OWNER_API_KEY`.
7. Rebuild on GitHub.

The collector stores only the fields the app sends. Do not collect data you do not need.

## Important platform note
An APK is Android-only. iPhones/iPads cannot install an Android APK. The `index.html` is responsive and can be hosted as a PWA for Safari/iOS and desktop/tablet browsers.

## GitHub APK
Push the project to GitHub. Open Actions → `🚀 Build SnakeByte APK` → Run workflow. Download the generated APK from the workflow Artifacts.

## Python runtime
The in-app runner loads Pyodide from the public CDN on first use, so first execution needs internet access. The educational UI, curriculum and progress remain available locally.


## v9 UI update
- Full-width responsive layout; centered on phones and tablets instead of a narrow one-sided column.
- iOS-inspired liquid-glass cards, floating navigation, animated background orbs, translucent editor and execution overlay.
- Python examples are rendered with double-quoted string literals where safely convertible.
- Android APK remains the Android build; iPhone/iPad use the responsive web/PWA build.

## v10: minimal iOS 27 motion + one-click APK
- Sliding glass tab pill, spring screen transitions, progress ring on the run sheet. Layout and content unchanged. Previous file kept as `index_v12_backup.html`.

### Make the APK (about 4 minutes, no setup)
1. Create a new GitHub repo and upload all files from this folder (keep the `.github` folder).
2. Open the **Actions** tab, pick **Build SnakeByte APK**, press **Run workflow**. (It also runs on every push to main.)
3. When it turns green, open **Releases** on the repo home page and download `SnakeByte-Python-Quest-v10-debug.apk`. Open it on your phone and allow "Install unknown apps".
